﻿namespace scbH60Store.Models
{
    public class ShoppingCart
    {
        public int ShoppingCartId { get; set; }
        public int CustomerId { get; set; }
        public DateTime DateCreated { get; set; }
    }
}
