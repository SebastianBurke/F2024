﻿namespace scbH60Store.Models
{
    public class GlobalSettings
    {
        public int Id { get; set; }
        public int MinStockLimit { get; set; }
        public int MaxStockLimit { get; set; }
    }

}
