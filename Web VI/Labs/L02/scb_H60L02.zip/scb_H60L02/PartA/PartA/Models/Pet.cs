﻿using System;
using System.Collections.Generic;

namespace PartA.Models;

public partial class Pet
{
    public decimal PetId { get; set; }

    public string? PetName { get; set; }
}
